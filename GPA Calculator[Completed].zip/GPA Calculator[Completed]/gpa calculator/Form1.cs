﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gpa_calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Create Combo box and add items
            credithour = Convert.ToInt32(comboBox1.SelectedItem);
            
        }
       public string name;
       public char grade;
       public int credithour;
       public double marks, points;

        private void s_marks_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(s_marks.Text)) {
                marks = Convert.ToDouble(s_marks.Text);
                switch (credithour)
                {
                    case 1:
                        if (marks <= 8)
                        {
                            grade = Convert.ToChar (textBox3.Text = "D");
                            points =Convert.ToDouble (textBox4.Text = "1.00");
                        }
                        else if (marks == 9)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "1.50");
                        }
                        else if (marks == 10)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "2.00");
                        }
                        else if (marks == 11)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "2.30");
                        }
                        else if (marks == 12)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "2.70");
                        }
                        else if (marks == 13)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "3.00");
                        }
                        else if (marks == 14)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "3.30");
                        }
                        else if (marks == 15)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "3.70");
                        }
                        else if (marks >= 16 && marks <=20)
                        {
                            grade = Convert.ToChar(textBox3.Text = "A");
                            points = Convert.ToDouble(textBox4.Text = "4.00");
                        }
                        else
                        {
                            MessageBox.Show("Invalid Marks");
                        }

                        break;
                    case 2:
                        if (marks <= 16)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "2.00");
                        }
                        else if (marks == 17)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "2.60");
                        }
                        else if (marks == 18)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "3.00");
                        }
                        else if (marks == 19)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "3.60");
                        }
                        else if (marks == 20)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "4.00");
                        }
                        else if (marks == 21)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "4.40");
                        }
                        else if (marks == 22)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "4.60");
                        }
                        else if (marks == 23)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "5.00");
                        }
                        else if (marks == 24)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "5.40");
                        }
                        else if (marks == 25)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "5.60");
                        }
                        else if (marks == 26)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "6.00");
                        }
                        else if (marks == 27)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "6.40");
                        }
                        else if (marks == 28)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "6.60");
                        }
                        else if (marks == 29)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "7.00");
                        }
                        else if (marks == 30)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "7.40");
                        }
                        else if (marks == 31)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "7.60");
                        }
                        else if (marks >=32 && marks< 40)
                        {
                            grade = Convert.ToChar(textBox3.Text = "A");
                            points = Convert.ToDouble(textBox4.Text = "8.00");
                        }
                        else
                        {
                            MessageBox.Show("Invalid Marks");
                        }
                        break;
                    case 3:
                        if (marks <= 24)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "3.00");
                        }
                        else if (marks == 25)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "3.60");
                        }
                        else if (marks == 26)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "3.90");
                        }
                        else if (marks == 27)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "4.50");
                        }
                        else if (marks == 28)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "5.10");
                        }
                        else if (marks == 29)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "5.40");
                        }
                        else if (marks == 30)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "6.00");
                        }
                        else if (marks == 31)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "6.30");
                        }
                        else if (marks == 32)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "6.60");
                        }
                        else if (marks == 33)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "6.90");
                        }
                        else if (marks == 34)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "7.20");
                        }
                        else if (marks == 35)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "7.50");
                        }
                        else if (marks == 36)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "8.10");
                        }
                        else if (marks == 37)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "8.40");
                        }
                        else if (marks == 38)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "8.70");
                        }
                        else if (marks == 39)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "9.00");
                        }
                        else if (marks == 40)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "9.30");
                        }
                        else if (marks == 41)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "9.60");
                        }
                        else if (marks == 42)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "9.90");
                        }
                        else if (marks == 43)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "10.20");
                        }
                        else if (marks == 44)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "10.50");
                        }
                        else if (marks == 45)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "11.10");
                        }
                        else if (marks == 46)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "11.40");
                        }
                        else if (marks == 47)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "11.70");
                        }
                        else if (marks >= 48 && marks <= 60)
                        {
                            grade = Convert.ToChar(textBox3.Text = "A");
                            points = Convert.ToDouble(textBox4.Text = "12.00");
                        }
                        else
                        {
                            MessageBox.Show("Invalid Marks");
                        }
                        break;
                    case 4: 
                        if (marks <= 32)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "4.00");
                        }
                        else if (marks == 33)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "4.40");
                        }
                        else if (marks == 34)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "5.20");
                        }
                        else if (marks == 35)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "5.60");
                        }
                        else if (marks == 36)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "6.00");
                        }
                        else if (marks == 37)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "6.40");
                        }
                        else if (marks == 38)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "7.20");
                        }
                        else if (marks == 39)
                        {
                            grade = Convert.ToChar(textBox3.Text = "D");
                            points = Convert.ToDouble(textBox4.Text = "7.60");
                        }
                        else if (marks == 40)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "8.00");
                        }
                        else if (marks == 41)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "8.40");
                        }
                        else if (marks == 42)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "8.80");
                        }
                        else if (marks == 43)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "8.80");
                        }
                        else if (marks == 44)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "9.20");
                        }
                        else if (marks == 45)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "9.60");
                        }
                        else if (marks == 46)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "10.00");
                        }
                        else if (marks == 47)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "10.40");
                        }
                        else if (marks == 48)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "10.80");
                        }
                        else if (marks == 49)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "10.80");
                        }
                        else if (marks == 50)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "11.20");
                        }
                        else if (marks == 51)
                        {
                            grade = Convert.ToChar(textBox3.Text = "C");
                            points = Convert.ToDouble(textBox4.Text = "11.60");
                        }
                        else if (marks == 52)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "12.00");
                        }
                        else if (marks == 53)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "12.00");
                        }
                        else if (marks == 54)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "12.40");
                        }
                        else if (marks == 55)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "12.80");
                        }
                        else if (marks == 56)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "13.20");
                        }
                        else if (marks == 57)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "13.60");
                        }
                        else if (marks == 58)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "14.00");
                        }
                        else if (marks == 59)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "14.40");
                        }
                        else if (marks == 60)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "14.80");
                        }
                        else if (marks == 61)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "14.80");
                        }
                        else if (marks == 62)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "15.20");
                        }
                        else if (marks == 63)
                        {
                            grade = Convert.ToChar(textBox3.Text = "B");
                            points = Convert.ToDouble(textBox4.Text = "15.60");
                        }
                        else if (marks >= 64 && marks < 80)
                        {
                            grade = Convert.ToChar(textBox3.Text = "A");
                            points = Convert.ToDouble(textBox4.Text = "16.00");
                        }
                        else
                        {
                            MessageBox.Show("Invalid Marks");
                        }
                        break;
                }
            }
            else
            {
                textBox3.Text = "";
                textBox4.Text = "";
            }
        }
       public double res, credit,point_s;
        public string[] final;
        private void button1_Click(object sender, EventArgs e)
        {

            if (button1.Text == "Add to grid")
            {
                string[] data = { name, Convert.ToString(credithour), Convert.ToString(marks), Convert.ToString(grade), Convert.ToString(points) };
                dataGridView1.Rows.Add(data);
            }
            else if (button1.Text == "Update")
            {
                dataGridView1.Rows[selectindex].Cells[0].Value = s_name.Text;
                dataGridView1.Rows[selectindex].Cells[1].Value = comboBox1.Text;
                dataGridView1.Rows[selectindex].Cells[2].Value = s_marks.Text;
                dataGridView1.Rows[selectindex].Cells[3].Value = textBox3.Text;
                dataGridView1.Rows[selectindex].Cells[4].Value = textBox4.Text;
                button1.Text = "Add to grid";
            }
            else
            {

            }
                credit = credit + credithour;
                point_s = point_s + points;

            // Add Remove Button in Datagridview
            DataGridViewButtonColumn removebutton = new DataGridViewButtonColumn();
            removebutton.FlatStyle = FlatStyle.Popup;
            removebutton.HeaderText = "Action";
            removebutton.Name = "Remove";
            removebutton.UseColumnTextForButtonValue = true;
            removebutton.Text = "Remove";
            removebutton.DefaultCellStyle.BackColor = Color.White;
            removebutton.DefaultCellStyle.ForeColor = Color.Red;
            removebutton.Width = 55;
            
            if(dataGridView1.Columns.Contains(removebutton.Name="Remove"))
            {

            }
            else
            {            
               dataGridView1.Columns.Add(removebutton);
                
            }
            // Add Edit Button in Datagridview
            DataGridViewButtonColumn updatebutton = new DataGridViewButtonColumn();
            updatebutton.FlatStyle = FlatStyle.Popup;
            updatebutton.HeaderText = "Action";
            updatebutton.Name = "Edit";
            updatebutton.UseColumnTextForButtonValue = true;
            updatebutton.Text = "Edit";
            updatebutton.DefaultCellStyle.BackColor = Color.White;
            updatebutton.DefaultCellStyle.ForeColor = Color.RoyalBlue;
            updatebutton.Width = 55;
            
            if (dataGridView1.Columns.Contains(updatebutton.Name = "Edit"))
            {

            }
            else
            {
                dataGridView1.Columns.Add(updatebutton);

            }
            s_name.Clear();
            comboBox1.SelectedIndex = -1;
            s_marks.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }
        int selectindex;
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 5)
            {
                if (MessageBox.Show("Do You Want To Remove This Row ", "Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int del_index = dataGridView1.CurrentCell.RowIndex;
                    dataGridView1.Rows.RemoveAt(del_index);
                }
                else
                {
                    MessageBox.Show("Row Not Removed", "Remove Row", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            // Update Rows in Data Grid View
            if (e.ColumnIndex == 6)
            {
                selectindex = e.RowIndex;
                s_name.Text = Convert.ToString(dataGridView1.Rows[selectindex].Cells[0].Value);
                comboBox1.Text = Convert.ToString(dataGridView1.Rows[selectindex].Cells[1].Value);
                s_marks.Text = Convert.ToString(dataGridView1.Rows[selectindex].Cells[2].Value);
                textBox3.Text = Convert.ToString(dataGridView1.Rows[selectindex].Cells[3].Value);
                textBox4.Text = Convert.ToString(dataGridView1.Rows[selectindex].Cells[4].Value);

                button1.Text = "Update";
                
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            res = point_s / credit;
            MessageBox.Show("Congratulation! You GPA is :" + res);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            name = s_name.Text;
        }
    }
}