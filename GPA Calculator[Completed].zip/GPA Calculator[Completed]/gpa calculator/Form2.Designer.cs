﻿namespace gpa_calculator
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Subject_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Grade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Credit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Credit_points = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.t_credit = new System.Windows.Forms.Label();
            this.t_cred_view = new System.Windows.Forms.Label();
            this.t_over_gpa = new System.Windows.Forms.Label();
            this.t_gpa = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Subject_name,
            this.Grade,
            this.Credit,
            this.Credit_points});
            this.dataGridView2.Location = new System.Drawing.Point(28, 87);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(444, 260);
            this.dataGridView2.TabIndex = 0;
            // 
            // Subject_name
            // 
            this.Subject_name.HeaderText = "Subject_name";
            this.Subject_name.Name = "Subject_name";
            // 
            // Grade
            // 
            this.Grade.HeaderText = "Grade";
            this.Grade.Name = "Grade";
            // 
            // Credit
            // 
            this.Credit.HeaderText = "Credit";
            this.Credit.Name = "Credit";
            // 
            // Credit_points
            // 
            this.Credit_points.HeaderText = "Credit_points";
            this.Credit_points.Name = "Credit_points";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(142, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Calculate GPA";
            // 
            // t_credit
            // 
            this.t_credit.AutoSize = true;
            this.t_credit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_credit.ForeColor = System.Drawing.Color.White;
            this.t_credit.Location = new System.Drawing.Point(99, 362);
            this.t_credit.Name = "t_credit";
            this.t_credit.Size = new System.Drawing.Size(114, 24);
            this.t_credit.TabIndex = 2;
            this.t_credit.Text = "Total Credits";
            // 
            // t_cred_view
            // 
            this.t_cred_view.AutoSize = true;
            this.t_cred_view.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_cred_view.ForeColor = System.Drawing.Color.White;
            this.t_cred_view.Location = new System.Drawing.Point(233, 362);
            this.t_cred_view.Name = "t_cred_view";
            this.t_cred_view.Size = new System.Drawing.Size(0, 24);
            this.t_cred_view.TabIndex = 3;
            // 
            // t_over_gpa
            // 
            this.t_over_gpa.AutoSize = true;
            this.t_over_gpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_over_gpa.ForeColor = System.Drawing.Color.White;
            this.t_over_gpa.Location = new System.Drawing.Point(233, 398);
            this.t_over_gpa.Name = "t_over_gpa";
            this.t_over_gpa.Size = new System.Drawing.Size(0, 24);
            this.t_over_gpa.TabIndex = 5;
            // 
            // t_gpa
            // 
            this.t_gpa.AutoSize = true;
            this.t_gpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t_gpa.ForeColor = System.Drawing.Color.White;
            this.t_gpa.Location = new System.Drawing.Point(100, 398);
            this.t_gpa.Name = "t_gpa";
            this.t_gpa.Size = new System.Drawing.Size(113, 24);
            this.t_gpa.TabIndex = 4;
            this.t_gpa.Text = "Overall GPA";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RoyalBlue;
            this.ClientSize = new System.Drawing.Size(501, 461);
            this.Controls.Add(this.t_over_gpa);
            this.Controls.Add(this.t_gpa);
            this.Controls.Add(this.t_cred_view);
            this.Controls.Add(this.t_credit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Subject_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Grade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Credit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Credit_points;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label t_credit;
        private System.Windows.Forms.Label t_cred_view;
        private System.Windows.Forms.Label t_over_gpa;
        private System.Windows.Forms.Label t_gpa;
    }
}