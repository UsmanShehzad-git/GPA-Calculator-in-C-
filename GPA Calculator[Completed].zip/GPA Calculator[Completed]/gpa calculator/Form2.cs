﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gpa_calculator
{
    public partial class Form2 : Form
    {
        public string s_name { get; set; }
        public string s_credit { get; set; }
        public string s_grade { get; set; }
        public string s_cred_point { get; set; }
        public string[] final_s = { };
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //string[] res = { s_name, s_grade, s_credit, s_cred_point };
             dataGridView2.Rows.Add(final_s);
        }
    }
}
